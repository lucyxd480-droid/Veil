import random

ENDINGS = [
    "The Veil lifted. Belief crowned its quiet architect.",
    "Truth never appeared — only perception remained.",
    "Influence endured when silence broke."
]

def ending():
    return random.choice(ENDINGS)
